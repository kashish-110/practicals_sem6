from qiskit import QuantumCircuit, transpile
from qiskit_ibm_runtime import QiskitRuntimeService, Sampler
import matplotlib.pyplot as plt
from qiskit_ibm_runtime import QiskitRuntimeService

# Replace YOUR_TOKEN_HERE with your IBM Quantum API token
QiskitRuntimeService.save_account(channel="ibm_quantum", token="4378aa1c43a9efaaf46ca81a5f783872c7f7a833be12396c1d72961dc44a16b014de93fab78badc0a80ef3f72415b2b321c67a50d5a8f98b6202b06b3a17e0b4", overwrite=True)


# STEP 1: Log in to IBM Quantum
# Make sure you've saved your IBM Quantum token to your local config or pass it directly
# Replace 'MY_IBM_QUANTUM_TOKEN' with your token if needed
service = QiskitRuntimeService()

# STEP 2: Build the "Hello World" Quantum Circuit
qc = QuantumCircuit(1, 1)   # 1 qubit, 1 classical bit
qc.h(0)                     # Hadamard gate to create superposition
qc.measure(0, 0)            # Measure qubit into classical bit

# Optional: Draw the circuit
qc.draw("mpl")
plt.show()

# STEP 3: Transpile circuit (optional for real backend)
qc_transpiled = transpile(qc, optimization_level=1)

# STEP 4: Run the circuit using the Sampler primitive (simulates it)
sampler = Sampler()
job = sampler.run(qc_transpiled)
result = job.result()

# STEP 5: Show Results
print("Hello, Quantum World! Measurement result probabilities:")
print(result.quasi_dists[0])
